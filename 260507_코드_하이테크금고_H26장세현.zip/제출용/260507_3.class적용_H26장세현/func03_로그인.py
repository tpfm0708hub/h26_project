from func01_공통설정 import get_conn, get_masked_input


class LoginService:
    def __init__(self):
        self.user_id = None
        self.user_password = None

    def input_login_info(self):
        self.user_id = input("아이디: ").strip()
        self.user_password = get_masked_input("비밀번호: ")

    def find_user(self):
        conn = None

        try:
            conn = get_conn()

            with conn.cursor() as cursor:
                cursor.execute("""
                    select user_idx, user_id, user_name
                    from user_info
                    where user_id = :1
                      and user_password = :2
                """, [self.user_id, self.user_password])

                row = cursor.fetchone()

                if row:
                    print(f"\n{row[2]}님 환영합니다!")
                    return {
                        "user_idx": row[0],
                        "user_id": row[1],
                        "user_name": row[2]
                    }

                print("\n시스템 오류: 입력정보 불일치")
                return None

        except Exception as e:
            print(f"시스템 오류: {e}")
            return None

        finally:
            if conn:
                conn.close()

    def run(self):
        print("\n[로그인]")
        self.input_login_info()
        return self.find_user()


def login():
    return LoginService().run()