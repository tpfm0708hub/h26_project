from func01_공통설정 import (
    get_conn,
    rollback_conn,
    SYSTEM_BANK,
    BANK_MENU,
    parse_money,
    format_money,
    get_masked_input,
    verify_current_password,
    print_transfer_summary,
    ask_confirm,
    print_bank_menu,
    get_user_name,
    get_or_create_target,
    sync_internal_target
)
from func05_내계좌조회 import choose_my_account


class TransferService:
    def __init__(self, user_idx):
        self.user_idx = user_idx

        self.transfer_mode = None
        self.is_internal = False
        self.detail_contnt = None
        self.to_bank = None

        self.sender_acnt_idx = None
        self.sender_acnt_no = None
        self.sender_old_blc = None
        self.sender_new_blc = None
        self.sender_name = None

        self.receiver_acnt_idx = None
        self.receiver_acnt_no = None
        self.receiver_old_blc = None
        self.receiver_name = None

        self.external_target_idx = None
        self.external_target_name = None
        self.external_target_old_blc = None

        self.amount = None

    def input_transfer_mode(self):
        print("\n[계좌이체]")
        print("1. 내계좌전송")
        print("2. 계좌이체")

        self.transfer_mode = input("선택: ").strip()

        if self.transfer_mode not in ('1', '2'):
            print("시스템 오류: 잘못된 선택")
            return False

        return True

    def choose_sender_account(self, cursor):
        sender = choose_my_account(cursor, self.user_idx, "계좌 선택: ")

        if not sender:
            return False

        self.sender_acnt_idx, self.sender_acnt_no, self.sender_old_blc = sender
        self.sender_name = get_user_name(cursor, self.user_idx)

        return True

    def process_my_account_transfer(self, cursor):
        self.is_internal = True
        self.detail_contnt = '내계좌전송'
        self.to_bank = SYSTEM_BANK

        receiver = choose_my_account(cursor, self.user_idx, "계좌 선택: ")

        if not receiver:
            return False

        self.receiver_acnt_idx, self.receiver_acnt_no, self.receiver_old_blc = receiver
        self.receiver_name = self.sender_name

        if self.sender_acnt_no == self.receiver_acnt_no:
            print("시스템 오류: 동일 계좌 이체 불가")
            return False

        return True

    def process_general_transfer(self, cursor):
        print_bank_menu()

        bank_choice = input("선택: ").strip()

        if bank_choice not in BANK_MENU:
            print("시스템 오류: 잘못된 선택")
            return False

        self.to_bank = BANK_MENU[bank_choice]

        if self.to_bank == SYSTEM_BANK:
            return self.process_internal_bank_transfer(cursor)

        return self.process_external_bank_transfer(cursor)

    def process_internal_bank_transfer(self, cursor):
        self.is_internal = True
        self.detail_contnt = '계좌이체'

        self.receiver_acnt_no = input("계좌번호: ").strip()

        if self.sender_acnt_no == self.receiver_acnt_no:
            print("시스템 오류: 동일 계좌 이체 불가")
            return False

        cursor.execute("""
            select a.acnt_idx, a.acnt_acnt, a.acnt_blc, u.user_name
            from acnt_info a
            join user_info u
              on a.user_idx = u.user_idx
            where a.acnt_acnt = :1
        """, [self.receiver_acnt_no])

        receiver = cursor.fetchone()

        if not receiver:
            print("시스템 오류: 계좌 정보 불일치")
            return False

        self.receiver_acnt_idx = receiver[0]
        self.receiver_acnt_no = receiver[1]
        self.receiver_old_blc = receiver[2]
        self.receiver_name = receiver[3]

        return True

    def process_external_bank_transfer(self, cursor):
        self.is_internal = False
        self.detail_contnt = '타행출금'
        self.receiver_acnt_no = input("계좌번호: ").strip()

        cursor.execute("""
            select target_idx, target_name, target_blc
            from target_info
            where target_bank = :1
              and target_acnt = :2
        """, [self.to_bank, self.receiver_acnt_no])

        ext_row = cursor.fetchone()

        if not ext_row:
            print("시스템 오류: 계좌 정보 불일치")
            return False

        self.external_target_idx = ext_row[0]
        self.external_target_name = ext_row[1]
        self.external_target_old_blc = ext_row[2]

        return True

    def input_amount(self):
        self.amount = parse_money(input("금액: "))

        if self.amount <= 0:
            print("시스템 오류: 0원 입력 불가")
            return False

        if self.amount > self.sender_old_blc:
            print("시스템 오류: 잔액 부족")
            return False

        return True

    def check_password(self, cursor):
        input_pw = get_masked_input("비밀번호: ")

        if not verify_current_password(cursor, self.user_idx, input_pw):
            print("시스템 오류: 비밀번호 불일치")
            return False

        return True

    def confirm_transfer(self):
        if self.is_internal:
            summary_name = self.receiver_name
            summary_acnt = self.receiver_acnt_no
        else:
            summary_name = self.external_target_name
            summary_acnt = self.receiver_acnt_no

        print_transfer_summary(
            title="계좌이체",
            from_acnt=self.sender_acnt_no,
            amount=self.amount,
            to_bank=self.to_bank,
            to_acnt=summary_acnt,
            to_name=summary_name
        )

        if not ask_confirm("이체하시겠습니까?"):
            print("계좌이체 취소")
            return False

        return True

    def update_sender_balance(self, cursor):
        self.sender_new_blc = self.sender_old_blc - self.amount

        cursor.execute("""
            update acnt_info
            set acnt_blc = :1
            where acnt_idx = :2
        """, [self.sender_new_blc, self.sender_acnt_idx])

        sync_internal_target(
            cursor,
            self.sender_acnt_no,
            self.sender_name,
            self.sender_new_blc
        )

    def process_internal_transfer_result(self, cursor):
        receiver_new_blc = self.receiver_old_blc + self.amount

        cursor.execute("""
            update acnt_info
            set acnt_blc = :1
            where acnt_idx = :2
        """, [receiver_new_blc, self.receiver_acnt_idx])

        receiver_target_idx = sync_internal_target(
            cursor,
            self.receiver_acnt_no,
            self.receiver_name,
            receiver_new_blc
        )

        sender_target_idx = sync_internal_target(
            cursor,
            self.sender_acnt_no,
            self.sender_name,
            self.sender_new_blc
        )

        cursor.execute("""
            insert into detail_info(
                acnt_idx, target_idx, detail_contnt,
                detail_type, detail_amnt, detail_blc
            )
            values (:1, :2, :3, :4, :5, :6)
        """, [
            self.sender_acnt_idx,
            receiver_target_idx,
            self.detail_contnt,
            '출금',
            self.amount,
            self.sender_new_blc
        ])

        cursor.execute("""
            insert into detail_info(
                acnt_idx, target_idx, detail_contnt,
                detail_type, detail_amnt, detail_blc
            )
            values (:1, :2, :3, :4, :5, :6)
        """, [
            self.receiver_acnt_idx,
            sender_target_idx,
            self.detail_contnt,
            '입금',
            self.amount,
            receiver_new_blc
        ])

    def process_external_transfer_result(self, cursor):
        external_target_new_blc = self.external_target_old_blc + self.amount

        cursor.execute("""
            update target_info
            set target_blc = :1
            where target_idx = :2
        """, [external_target_new_blc, self.external_target_idx])

        get_or_create_target(
            cursor,
            self.to_bank,
            self.receiver_acnt_no,
            self.external_target_name,
            external_target_new_blc
        )

        cursor.execute("""
            insert into detail_info(
                acnt_idx, target_idx, detail_contnt,
                detail_type, detail_amnt, detail_blc
            )
            values (:1, :2, :3, :4, :5, :6)
        """, [
            self.sender_acnt_idx,
            self.external_target_idx,
            self.detail_contnt,
            '출금',
            self.amount,
            self.sender_new_blc
        ])

    def run(self):
        if not self.input_transfer_mode():
            return

        conn = None

        try:
            conn = get_conn()

            with conn.cursor() as cursor:
                if not self.choose_sender_account(cursor):
                    return

                if self.transfer_mode == '1':
                    if not self.process_my_account_transfer(cursor):
                        return
                else:
                    if not self.process_general_transfer(cursor):
                        return

                if not self.input_amount():
                    return

                if not self.check_password(cursor):
                    return

                if not self.confirm_transfer():
                    return

                self.update_sender_balance(cursor)

                if self.is_internal:
                    self.process_internal_transfer_result(cursor)
                else:
                    self.process_external_transfer_result(cursor)

            conn.commit()
            print(f"계좌이체 완료: 잔액 {format_money(self.sender_new_blc)}원")

        except Exception as e:
            rollback_conn(conn)
            print(f"시스템 오류: {e}")

        finally:
            if conn:
                conn.close()


def transfer(user_idx):
    TransferService(user_idx).run()