from func01_공통설정 import (
    get_conn,
    rollback_conn,
    validate_signup_id,
    validate_signup_password
)


class SignupService:
    def __init__(self):
        self.user_id = None
        self.user_password = None
        self.user_name = None
        self.user_address = None

    def input_user_id(self):
        while True:
            print("\n아이디: 영문 소문자 및 숫자 조합(5자 이상)")
            user_id = input("아이디: ").strip()

            if not validate_signup_id(user_id):
                print("시스템 오류: 입력형식 오류")
                continue

            if self.is_duplicate_id(user_id):
                print("시스템 오류: 중복 ID")
                continue

            self.user_id = user_id
            break

    def is_duplicate_id(self, user_id):
        conn = None

        try:
            conn = get_conn()

            with conn.cursor() as cursor:
                cursor.execute("""
                    select count(*)
                    from user_info
                    where user_id = :1
                """, [user_id])

                cnt = cursor.fetchone()[0]
                return cnt > 0

        except Exception as e:
            print(f"시스템 오류: {e}")
            return True

        finally:
            if conn:
                conn.close()

    def input_password(self):
        while True:
            print("\n비밀번호: 숫자 6자리")
            user_password = input("비밀번호: ").strip()

            if not validate_signup_password(user_password):
                print("시스템 오류: 입력형식 오류")
                continue

            user_password_check = input("비밀번호 확인: ").strip()

            if user_password != user_password_check:
                print("시스템 오류: 비밀번호 불일치")
                continue

            self.user_password = user_password
            break

    def input_user_name(self):
        while True:
            user_name = input("이름: ").strip()

            if not user_name:
                print("시스템 오류: 필수 입력값 누락")
                continue

            self.user_name = user_name
            break

    def input_user_address(self):
        while True:
            user_address = input("주소: ").strip()

            if not user_address:
                print("시스템 오류: 필수 입력값 누락")
                continue

            self.user_address = user_address
            break

    def save_user(self):
        conn = None

        try:
            conn = get_conn()

            with conn.cursor() as cursor:
                cursor.execute("""
                    insert into user_info(
                        user_id, user_password, user_name, user_address
                    )
                    values (:1, :2, :3, :4)
                """, [
                    self.user_id,
                    self.user_password,
                    self.user_name,
                    self.user_address
                ])

            conn.commit()
            print("회원가입 완료")

        except Exception as e:
            rollback_conn(conn)
            print(f"시스템 오류: {e}")

        finally:
            if conn:
                conn.close()

    def run(self):
        print("\n[회원가입]")

        self.input_user_id()
        self.input_password()
        self.input_user_name()
        self.input_user_address()
        self.save_user()


def signup():
    SignupService().run()