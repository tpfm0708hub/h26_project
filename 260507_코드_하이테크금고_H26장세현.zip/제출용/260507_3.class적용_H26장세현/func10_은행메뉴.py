from func04_계좌생성 import create_account
from func05_내계좌조회 import show_my_accounts
from func06_입금 import deposit
from func07_출금 import withdraw
from func08_계좌이체 import transfer
from func09_거래내역조회 import show_transaction_history


class BankMenuController:
    def __init__(self, user):
        self.user = user

    def print_menu(self):
        print(f"\n--- {self.user['user_name']}님 업무 선택 ---")
        print("1. 내 계좌 생성")
        print("2. 내 계좌 조회")
        print("3. 입금")
        print("4. 출금")
        print("5. 계좌이체")
        print("6. 거래내역 조회")
        print("7. 로그아웃")

    def run_selected_menu(self, menu):
        if menu == '1':
            create_account(self.user['user_idx'])

        elif menu == '2':
            show_my_accounts(self.user['user_idx'])

        elif menu == '3':
            deposit(self.user['user_idx'])

        elif menu == '4':
            withdraw(self.user['user_idx'])

        elif menu == '5':
            transfer(self.user['user_idx'])

        elif menu == '6':
            show_transaction_history(self.user['user_idx'])

        elif menu == '7':
            return False

        else:
            print("시스템 오류: 잘못된 선택")

        return True

    def run(self):
        while True:
            self.print_menu()
            menu = input("선택: ").strip()

            if not self.run_selected_menu(menu):
                break


def bank_menu(user):
    BankMenuController(user).run()