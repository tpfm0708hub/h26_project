import oracledb
import re
import sys
from getpass import getpass

try:
    import msvcrt
    HAS_MSVCRT = True
except ImportError:
    HAS_MSVCRT = False


# =========================================================
# 1. DB 및 은행 기본 설정
# =========================================================
class DBConfig:
    dict_01 = {
        'user': 'hr',
        'password': 'hr',
        'url': 'localhost:1521/free'
    }

    @classmethod
    def get_conn(cls):
        return oracledb.connect(
            user=cls.dict_01['user'],
            password=cls.dict_01['password'],
            dsn=cls.dict_01['url']
        )


class BankConfig:
    SYSTEM_BANK = "하이테크금고"

    BANK_MENU = {
        '0': SYSTEM_BANK,
        '1': '신한은행',
        '2': 'KB국민은행',
        '3': '하나은행',
        '4': '우리은행'
    }


# 기존 코드 호환용 전역 변수
dict_01 = DBConfig.dict_01
SYSTEM_BANK = BankConfig.SYSTEM_BANK
BANK_MENU = BankConfig.BANK_MENU


# =========================================================
# 2. DB 공통 처리 클래스
# =========================================================
class DBUtil:
    @staticmethod
    def rollback_conn(conn):
        try:
            if conn:
                conn.rollback()
        except Exception:
            pass


# =========================================================
# 3. 금액 처리 클래스
# =========================================================
class MoneyUtil:
    @staticmethod
    def parse_money(amount_str):
        try:
            cleaned = str(amount_str).replace(',', '').strip()
            return int(cleaned)
        except Exception:
            return -1

    @staticmethod
    def format_money(amount):
        return f"{int(amount):,}"


# =========================================================
# 4. 회원가입 입력 검증 클래스
# =========================================================
class SignupValidator:
    @staticmethod
    def validate_signup_id(user_id):
        pattern = r'^(?=.*[a-z])(?=.*\d)[a-z\d]{5,}$'
        return bool(re.fullmatch(pattern, user_id))

    @staticmethod
    def validate_signup_password(user_password):
        pattern = r'^\d{6}$'
        return bool(re.fullmatch(pattern, user_password))


# =========================================================
# 5. 입력 처리 클래스
# =========================================================
class InputUtil:
    @staticmethod
    def get_hidden_input(prompt="비밀번호: "):
        return getpass(prompt)

    @staticmethod
    def get_masked_input(prompt="비밀번호: "):
        if not HAS_MSVCRT:
            return InputUtil.get_hidden_input(prompt)

        print(prompt, end='', flush=True)
        password = ""

        while True:
            ch = msvcrt.getch()

            if ch in (b'\r', b'\n'):
                print()
                break

            if ch == b'\x08':
                if password:
                    password = password[:-1]
                    sys.stdout.write('\b \b')
                    sys.stdout.flush()
                continue

            if ch in (b'\x00', b'\xe0'):
                try:
                    msvcrt.getch()
                except Exception:
                    pass
                continue

            try:
                decoded = ch.decode('utf-8')
            except UnicodeDecodeError:
                decoded = ''

            if decoded:
                password += decoded
                sys.stdout.write('*')
                sys.stdout.flush()

        return password

    @staticmethod
    def ask_confirm(message):
        while True:
            choice = input(f"{message} (Y/N): ").strip().upper()

            if choice == 'Y':
                return True

            if choice == 'N':
                return False

            print("Y 또는 N만 입력해 주세요.")


# =========================================================
# 6. 사용자 관련 공통 서비스
# =========================================================
class UserService:
    @staticmethod
    def verify_current_password(cursor, user_idx, input_password):
        cursor.execute("""
            select user_password
            from user_info
            where user_idx = :1
        """, [user_idx])

        row = cursor.fetchone()

        if not row:
            return False

        return row[0] == input_password

    @staticmethod
    def get_user_name(cursor, user_idx):
        cursor.execute("""
            select user_name
            from user_info
            where user_idx = :1
        """, [user_idx])

        row = cursor.fetchone()

        if row:
            return row[0]

        return None


# =========================================================
# 7. 거래대상 관련 서비스
# =========================================================
class TargetService:
    @staticmethod
    def get_or_create_target(cursor, bank, target_acnt, target_name, target_blc=0):
        cursor.execute("""
            select target_idx
            from target_info
            where target_bank = :1
              and target_acnt = :2
        """, [bank, target_acnt])

        row = cursor.fetchone()

        if row:
            target_idx = row[0]

            cursor.execute("""
                update target_info
                set target_name = :1,
                    target_blc = :2
                where target_idx = :3
            """, [target_name, target_blc, target_idx])

            return target_idx

        cursor.execute("""
            insert into target_info(
                target_bank, target_acnt, target_name, target_blc
            )
            values (:1, :2, :3, :4)
        """, [bank, target_acnt, target_name, target_blc])

        cursor.execute("""
            select target_idx
            from target_info
            where target_bank = :1
              and target_acnt = :2
        """, [bank, target_acnt])

        return cursor.fetchone()[0]

    @staticmethod
    def sync_internal_target(cursor, acnt_no, user_name, balance):
        return TargetService.get_or_create_target(
            cursor,
            BankConfig.SYSTEM_BANK,
            acnt_no,
            user_name,
            balance
        )


# =========================================================
# 8. 출력 관련 서비스
# =========================================================
class PrintService:
    @staticmethod
    def print_transfer_summary(
        title,
        from_acnt,
        amount,
        to_bank='-',
        to_acnt='-',
        to_name='-'
    ):
        print("\n" + "=" * 60)
        print(f"[{title} 거래 요약]")
        print(f"출금계좌 : {from_acnt}")
        print(f"입금은행 : {to_bank}")
        print(f"입금계좌 : {to_acnt}")
        print(f"예금주명 : {to_name}")
        print(f"거래금액 : {MoneyUtil.format_money(amount)}원")
        print("=" * 60)

    @staticmethod
    def print_bank_menu():
        print("\n[은행 선택]")

        for key, bank_name in BankConfig.BANK_MENU.items():
            print(f"{key}. {bank_name}")


# =========================================================
# 9. 기존 함수명 호환용 래퍼
# =========================================================
def get_conn():
    return DBConfig.get_conn()


def rollback_conn(conn):
    return DBUtil.rollback_conn(conn)


def parse_money(amount_str):
    return MoneyUtil.parse_money(amount_str)


def format_money(amount):
    return MoneyUtil.format_money(amount)


def validate_signup_id(user_id):
    return SignupValidator.validate_signup_id(user_id)


def validate_signup_password(user_password):
    return SignupValidator.validate_signup_password(user_password)


def get_hidden_input(prompt="비밀번호: "):
    return InputUtil.get_hidden_input(prompt)


def get_masked_input(prompt="비밀번호: "):
    return InputUtil.get_masked_input(prompt)


def ask_confirm(message):
    return InputUtil.ask_confirm(message)


def verify_current_password(cursor, user_idx, input_password):
    return UserService.verify_current_password(cursor, user_idx, input_password)


def get_user_name(cursor, user_idx):
    return UserService.get_user_name(cursor, user_idx)


def get_or_create_target(cursor, bank, target_acnt, target_name, target_blc=0):
    return TargetService.get_or_create_target(
        cursor,
        bank,
        target_acnt,
        target_name,
        target_blc
    )


def sync_internal_target(cursor, acnt_no, user_name, balance):
    return TargetService.sync_internal_target(
        cursor,
        acnt_no,
        user_name,
        balance
    )


def print_transfer_summary(
    title,
    from_acnt,
    amount,
    to_bank='-',
    to_acnt='-',
    to_name='-'
):
    return PrintService.print_transfer_summary(
        title,
        from_acnt,
        amount,
        to_bank,
        to_acnt,
        to_name
    )


def print_bank_menu():
    return PrintService.print_bank_menu()