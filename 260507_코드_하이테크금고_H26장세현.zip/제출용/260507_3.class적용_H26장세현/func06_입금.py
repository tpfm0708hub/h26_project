from func01_공통설정 import (
    get_conn,
    rollback_conn,
    parse_money,
    format_money,
    get_user_name,
    sync_internal_target
)
from func05_내계좌조회 import get_my_account


class DepositService:
    def __init__(self, user_idx):
        self.user_idx = user_idx
        self.acnt_no = None
        self.amount = None
        self.acnt_idx = None
        self.old_blc = None
        self.new_blc = None

    def input_deposit_info(self):
        self.acnt_no = input("계좌번호: ").strip()
        self.amount = parse_money(input("금액: ").strip())

        if self.amount <= 0:
            print("시스템 오류: 0원 입력 불가")
            return False

        return True

    def check_account(self, cursor):
        my_acnt = get_my_account(cursor, self.user_idx, self.acnt_no)

        if not my_acnt:
            print("시스템 오류: 계좌 정보 불일치")
            return False

        self.acnt_idx, _, self.old_blc = my_acnt
        return True

    def update_balance(self, cursor):
        self.new_blc = self.old_blc + self.amount

        cursor.execute("""
            update acnt_info
            set acnt_blc = :1
            where acnt_idx = :2
        """, [self.new_blc, self.acnt_idx])

    def sync_target(self, cursor):
        user_name = get_user_name(cursor, self.user_idx)

        sync_internal_target(
            cursor,
            self.acnt_no,
            user_name,
            self.new_blc
        )

    def insert_detail(self, cursor):
        cursor.execute("""
            insert into detail_info(
                acnt_idx, target_idx, detail_contnt,
                detail_type, detail_amnt, detail_blc
            )
            values (:1, :2, :3, :4, :5, :6)
        """, [
            self.acnt_idx,
            None,
            '현금입금',
            '입금',
            self.amount,
            self.new_blc
        ])

    def run(self):
        if not self.input_deposit_info():
            return

        conn = None

        try:
            conn = get_conn()

            with conn.cursor() as cursor:
                if not self.check_account(cursor):
                    return

                self.update_balance(cursor)
                self.sync_target(cursor)
                self.insert_detail(cursor)

            conn.commit()
            print(f"입금 완료: 잔액 {format_money(self.new_blc)}원")

        except Exception as e:
            rollback_conn(conn)
            print(f"시스템 오류: {e}")

        finally:
            if conn:
                conn.close()


def deposit(user_idx):
    DepositService(user_idx).run()