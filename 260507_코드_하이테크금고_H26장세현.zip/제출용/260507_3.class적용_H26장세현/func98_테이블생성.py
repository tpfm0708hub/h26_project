import oracledb
from func01_공통설정 import dict_01


class SchemaManager:
    def __init__(self):
        self.conn = None

    def connect(self):
        self.conn = oracledb.connect(
            user=dict_01['user'],
            password=dict_01['password'],
            dsn=dict_01['url']
        )

    def safe_execute(self, cursor, sql):
        try:
            cursor.execute(sql)
        except Exception:
            pass

    def drop_objects(self, cursor):
        self.safe_execute(cursor, "drop table detail_info cascade constraints")
        self.safe_execute(cursor, "drop table target_info cascade constraints")
        self.safe_execute(cursor, "drop table acnt_info cascade constraints")
        self.safe_execute(cursor, "drop table user_info cascade constraints")

        self.safe_execute(cursor, "drop sequence seq_detail_idx")
        self.safe_execute(cursor, "drop sequence seq_target_idx")
        self.safe_execute(cursor, "drop sequence seq_acnt_acnt")
        self.safe_execute(cursor, "drop sequence seq_acnt_idx")
        self.safe_execute(cursor, "drop sequence seq_user_idx")

    def create_sequences(self, cursor):
        cursor.execute("""
            create sequence seq_user_idx
            start with 1
            increment by 1
            nocache
            nocycle
        """)

        cursor.execute("""
            create sequence seq_acnt_idx
            start with 1
            increment by 1
            nocache
            nocycle
        """)

        cursor.execute("""
            create sequence seq_acnt_acnt
            start with 1000000001
            increment by 1
            nocache
            nocycle
        """)

        cursor.execute("""
            create sequence seq_target_idx
            start with 1
            increment by 1
            nocache
            nocycle
        """)

        cursor.execute("""
            create sequence seq_detail_idx
            start with 1
            increment by 1
            nocache
            nocycle
        """)

    def create_user_info(self, cursor):
        cursor.execute("""
            create table user_info(
                user_idx        number default seq_user_idx.nextval primary key,
                user_id         varchar2(20) not null,
                user_password   char(6) not null,
                user_name       varchar2(20) not null,
                user_address    varchar2(100) not null,

                constraint uq_user_id unique (user_id)
            )
        """)

    def create_acnt_info(self, cursor):
        cursor.execute("""
            create table acnt_info(
                acnt_idx        number default seq_acnt_idx.nextval primary key,
                user_idx        number not null,
                acnt_acnt       varchar2(40) default to_char(seq_acnt_acnt.nextval) not null,
                acnt_blc        number default 0 not null,

                constraint uq_acnt_acnt unique (acnt_acnt),
                constraint ck_acnt_blc check (acnt_blc >= 0),
                constraint fk_acnt_user foreign key (user_idx)
                    references user_info(user_idx)
            )
        """)

    def create_target_info(self, cursor):
        cursor.execute("""
            create table target_info(
                target_idx      number default seq_target_idx.nextval primary key,
                target_bank     varchar2(30) not null,
                target_acnt     varchar2(30) not null,
                target_blc      number default 0 not null,
                target_name     varchar2(20) not null,

                constraint uq_target_bank_acnt unique (target_bank, target_acnt),
                constraint ck_target_blc check (target_blc >= 0)
            )
        """)

    def create_detail_info(self, cursor):
        cursor.execute("""
            create table detail_info(
                detail_idx      number default seq_detail_idx.nextval primary key,
                acnt_idx        number not null,
                target_idx      number,
                detail_date     timestamp default systimestamp not null,
                detail_contnt   varchar2(100) not null,
                detail_type     varchar2(20) not null,
                detail_amnt     number not null,
                detail_blc      number not null,

                constraint fk_detail_acnt foreign key (acnt_idx)
                    references acnt_info(acnt_idx),

                constraint fk_detail_target foreign key (target_idx)
                    references target_info(target_idx),

                constraint ck_detail_type_info check (detail_type in ('입금', '출금')),
                constraint ck_detail_amnt_info check (detail_amnt > 0),
                constraint ck_detail_blc_info check (detail_blc >= 0)
            )
        """)

    def run(self):
        try:
            self.connect()

            with self.conn.cursor() as cursor:
                self.drop_objects(cursor)
                self.create_sequences(cursor)
                self.create_user_info(cursor)
                self.create_acnt_info(cursor)
                self.create_target_info(cursor)
                self.create_detail_info(cursor)

            self.conn.commit()
            print("테이블 및 시퀀스 생성이 완료되었습니다.")

        except Exception as e:
            if self.conn:
                self.conn.rollback()
            print("테이블 생성 중 오류 발생:", e)

        finally:
            if self.conn:
                self.conn.close()


def create_schema():
    SchemaManager().run()


if __name__ == "__main__":
    create_schema()