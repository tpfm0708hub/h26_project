from func01_공통설정 import (
    get_conn,
    rollback_conn,
    get_user_name,
    sync_internal_target
)


class AccountCreateService:
    def __init__(self, user_idx):
        self.user_idx = user_idx
        self.new_acnt_no = None

    def create_new_account_number(self, cursor):
        cursor.execute("select to_char(seq_acnt_acnt.nextval) from dual")
        self.new_acnt_no = cursor.fetchone()[0]

    def insert_account(self, cursor):
        cursor.execute("""
            insert into acnt_info(user_idx, acnt_acnt, acnt_blc)
            values (:1, :2, 0)
        """, [self.user_idx, self.new_acnt_no])

    def sync_target(self, cursor):
        user_name = get_user_name(cursor, self.user_idx)

        sync_internal_target(
            cursor,
            self.new_acnt_no,
            user_name,
            0
        )

    def run(self):
        conn = None

        try:
            conn = get_conn()

            with conn.cursor() as cursor:
                self.create_new_account_number(cursor)
                self.insert_account(cursor)
                self.sync_target(cursor)

            conn.commit()
            print(f"계좌 생성 완료: {self.new_acnt_no}")

        except Exception as e:
            rollback_conn(conn)
            print(f"시스템 오류: {e}")

        finally:
            if conn:
                conn.close()


def create_account(user_idx):
    AccountCreateService(user_idx).run()