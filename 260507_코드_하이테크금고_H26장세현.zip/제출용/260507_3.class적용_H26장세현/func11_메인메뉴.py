from func02_회원가입 import signup
from func03_로그인 import login
from func10_은행메뉴 import bank_menu


class MainMenuController:
    def print_menu(self):
        print("\n=== 하이테크금고 콘솔 뱅킹 ===")
        print("1. 회원가입")
        print("2. 로그인")
        print("3. 종료")

    def run_selected_menu(self, menu):
        if menu == '1':
            signup()

        elif menu == '2':
            user = login()

            if user:
                bank_menu(user)

        elif menu == '3':
            print("시스템 종료")
            return False

        else:
            print("시스템 오류: 잘못된 선택")

        return True

    def run(self):
        while True:
            self.print_menu()
            menu = input("선택: ").strip()

            if not self.run_selected_menu(menu):
                break


def main():
    MainMenuController().run()


if __name__ == "__main__":
    main()