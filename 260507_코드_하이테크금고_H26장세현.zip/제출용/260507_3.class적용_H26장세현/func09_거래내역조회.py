from func01_공통설정 import get_conn, format_money
from func05_내계좌조회 import choose_my_account


class TransactionHistoryService:
    def __init__(self, user_idx):
        self.user_idx = user_idx
        self.acnt_idx = None
        self.acnt_no = None

    def choose_account(self, cursor):
        selected_account = choose_my_account(cursor, self.user_idx, "선택(번호): ")

        if not selected_account:
            return False

        self.acnt_idx, self.acnt_no, _ = selected_account
        return True

    def fetch_history(self, cursor):
        cursor.execute("""
            select
                to_char(d.detail_date, 'YYYY-MM-DD HH24:MI:SS'),
                d.detail_contnt,
                d.detail_type,
                d.detail_amnt,
                d.detail_blc,
                nvl(t.target_bank, '-'),
                nvl(t.target_acnt, '-'),
                nvl(t.target_name, '-')
            from detail_info d
            left join target_info t
              on d.target_idx = t.target_idx
            where d.acnt_idx = :1
            order by d.detail_date desc, d.detail_idx desc
        """, [self.acnt_idx])

        return cursor.fetchall()

    def print_history(self, rows):
        if not rows:
            print(f"\n[거래 내역 - {self.acnt_no}]")
            print("시스템 오류: 내역 없음")
            return

        print(f"\n[거래 내역 - {self.acnt_no}]")
        print("-" * 110)

        for row in rows:
            bank_display = row[5] if row[5] != '-' else "-"
            print(
                f"[{row[0]}] {row[1]}({row[2]}) | "
                f"금액:{format_money(row[3]):>10} | "
                f"잔액:{format_money(row[4]):>10} | "
                f"상대:{bank_display} / {row[6]} / {row[7]}"
            )

        print("-" * 110)

    def run(self):
        print("\n[거래내역 조회]")

        conn = None

        try:
            conn = get_conn()

            with conn.cursor() as cursor:
                if not self.choose_account(cursor):
                    return

                rows = self.fetch_history(cursor)
                self.print_history(rows)

        except Exception as e:
            print(f"시스템 오류: {e}")

        finally:
            if conn:
                conn.close()


def show_transaction_history(user_idx):
    TransactionHistoryService(user_idx).run()