from func01_공통설정 import get_conn


class SampleDataSeeder:
    def insert_users(self, cursor):
        user_rows = [
            {'id': 'test01', 'pw': '1111', 'name': '김민수', 'addr': '서울시 강남구'},
            {'id': 'test02', 'pw': '2222', 'name': '이서연', 'addr': '성남시 수정구'},
            {'id': 'test03', 'pw': '3333', 'name': '박지훈', 'addr': '수원시 영통구'}
        ]

        for row in user_rows:
            cursor.execute("""
                merge into user_info u
                using dual
                on (u.user_id = :id)
                when not matched then
                    insert (user_id, user_password, user_name, user_address)
                    values (:id, :pw, :name, :addr)
            """, row)

    def get_user_map(self, cursor):
        cursor.execute("""
            select user_idx, user_id
            from user_info
            where user_id in ('test01', 'test02', 'test03')
        """)

        return {user_id: user_idx for user_idx, user_id in cursor.fetchall()}

    def insert_accounts(self, cursor, user_map):
        acnt_rows = [
            {'idx': user_map['test01'], 'acnt': '9999999997', 'blc': 50000},
            {'idx': user_map['test02'], 'acnt': '9999999998', 'blc': 70000},
            {'idx': user_map['test03'], 'acnt': '9999999999', 'blc': 30000}
        ]

        for row in acnt_rows:
            cursor.execute("""
                merge into acnt_info a
                using dual
                on (a.acnt_acnt = :acnt)
                when not matched then
                    insert (user_idx, acnt_acnt, acnt_blc)
                    values (:idx, :acnt, :blc)
            """, row)

    def get_account_map(self, cursor):
        cursor.execute("""
            select acnt_idx, acnt_acnt
            from acnt_info
            where acnt_acnt in ('9999999997', '9999999998', '9999999999')
        """)

        return {acnt_no: acnt_idx for acnt_idx, acnt_no in cursor.fetchall()}

    def insert_targets(self, cursor):
        target_rows = [
            {'bank': '국민은행', 'acnt': '333344445555', 'name': '홍길동', 'blc': 100000},
            {'bank': '신한은행', 'acnt': '777788889999', 'name': '김하늘', 'blc': 120000},
            {'bank': '하이테크금고', 'acnt': '9999999998', 'name': '이서연', 'blc': 70000},
            {'bank': '하이테크금고', 'acnt': '9999999997', 'name': '김민수', 'blc': 50000}
        ]

        for row in target_rows:
            cursor.execute("""
                merge into target_info t
                using dual
                on (t.target_bank = :bank and t.target_acnt = :acnt)
                when not matched then
                    insert (target_bank, target_acnt, target_name, target_blc)
                    values (:bank, :acnt, :name, :blc)
                when matched then
                    update set t.target_name = :name,
                               t.target_blc = :blc
            """, row)

    def get_target_map(self, cursor):
        cursor.execute("""
            select target_idx, target_bank, target_acnt
            from target_info
            where (target_bank = '국민은행' and target_acnt = '333344445555')
               or (target_bank = '신한은행' and target_acnt = '777788889999')
               or (target_bank = '하이테크금고' and target_acnt = '9999999998')
               or (target_bank = '하이테크금고' and target_acnt = '9999999997')
        """)

        return {(bank, acnt): idx for idx, bank, acnt in cursor.fetchall()}

    def insert_details(self, cursor, acnt_map, target_map):
        detail_rows = [
            (
                acnt_map['9999999997'],
                None,
                '현금입금',
                '입금',
                20000,
                70000
            ),
            (
                acnt_map['9999999997'],
                None,
                '현금출금',
                '출금',
                10000,
                60000
            ),
            (
                acnt_map['9999999997'],
                target_map[('하이테크금고', '9999999998')],
                '계좌이체',
                '출금',
                15000,
                45000
            ),
            (
                acnt_map['9999999998'],
                target_map[('하이테크금고', '9999999997')],
                '계좌이체',
                '입금',
                15000,
                85000
            ),
            (
                acnt_map['9999999999'],
                target_map[('국민은행', '333344445555')],
                '타행입금',
                '입금',
                5000,
                35000
            ),
            (
                acnt_map['9999999998'],
                target_map[('신한은행', '777788889999')],
                '타행출금',
                '출금',
                3000,
                82000
            )
        ]

        for row in detail_rows:
            cursor.execute("""
                insert into detail_info(
                    acnt_idx, target_idx, detail_contnt,
                    detail_type, detail_amnt, detail_blc
                )
                values (:1, :2, :3, :4, :5, :6)
            """, row)

    def run(self):
        try:
            with get_conn() as conn:
                with conn.cursor() as cursor:
                    self.insert_users(cursor)
                    user_map = self.get_user_map(cursor)

                    self.insert_accounts(cursor, user_map)
                    acnt_map = self.get_account_map(cursor)

                    self.insert_targets(cursor)
                    target_map = self.get_target_map(cursor)

                    self.insert_details(cursor, acnt_map, target_map)

                conn.commit()
                print("샘플 데이터 입력이 완료되었습니다.")

        except Exception as e:
            print("샘플 데이터 입력 중 오류 발생:", e)


def insert_sample_data():
    SampleDataSeeder().run()


if __name__ == "__main__":
    insert_sample_data()