import oracledb

dict_01 = {
    'user': 'hr',
    'password': 'hr',
    'url': 'localhost:1521/free'
}

SYSTEM_BANK = "하이테크금고"


def get_conn():
    return oracledb.connect(
        user=dict_01['user'],
        password=dict_01['password'],
        dsn=dict_01['url']
    )