import oracledb

dict_01 = {
    'user': 'hr',
    'password': 'hr',
    'url': 'localhost:1521/free'
}

# =========================================================
# 1) sequence 생성
# =========================================================

### user_info PK sequence
with oracledb.connect(user=dict_01['user'], password=dict_01['password'], dsn=dict_01['url']) as conn:
    with conn.cursor() as cursor:
        cursor.execute("""
create sequence seq_user_idx
start with 1
increment by 1
nocache
nocycle
""")

### acnt_info PK sequence
with oracledb.connect(user=dict_01['user'], password=dict_01['password'], dsn=dict_01['url']) as conn:
    with conn.cursor() as cursor:
        cursor.execute("""
create sequence seq_acnt_idx
start with 1
increment by 1
nocache
nocycle
""")

### 계좌번호 생성용 sequence
with oracledb.connect(user=dict_01['user'], password=dict_01['password'], dsn=dict_01['url']) as conn:
    with conn.cursor() as cursor:
        cursor.execute("""
create sequence seq_acnt_acnt
start with 1000000001
increment by 1
nocache
nocycle
""")

### target_info PK sequence
with oracledb.connect(user=dict_01['user'], password=dict_01['password'], dsn=dict_01['url']) as conn:
    with conn.cursor() as cursor:
        cursor.execute("""
create sequence seq_target_idx
start with 1
increment by 1
nocache
nocycle
""")

### detail_info PK sequence
with oracledb.connect(user=dict_01['user'], password=dict_01['password'], dsn=dict_01['url']) as conn:
    with conn.cursor() as cursor:
        cursor.execute("""
create sequence seq_detail_idx
start with 1
increment by 1
nocache
nocycle
""")


# =========================================================
# 2) table 생성
# =========================================================

### user_info 테이블
with oracledb.connect(user=dict_01['user'], password=dict_01['password'], dsn=dict_01['url']) as conn:
    with conn.cursor() as cursor:
        cursor.execute("""
create table user_info(
    user_idx        number default seq_user_idx.nextval primary key, -- 회원 PK
    user_id         varchar2(12) not null,                           -- 로그인 ID
    user_password   varchar2(20) not null,                           -- 비밀번호
    user_name       varchar2(20) not null,                           -- 회원 이름
    user_address    varchar2(100) not null,                          -- 회원 주소

    constraint uq_user_id unique (user_id)                           -- 아이디 중복 방지
)
""")


### acnt_info 테이블
with oracledb.connect(user=dict_01['user'], password=dict_01['password'], dsn=dict_01['url']) as conn:
    with conn.cursor() as cursor:
        cursor.execute("""
create table acnt_info(
    acnt_idx        number default seq_acnt_idx.nextval primary key,          -- 계좌 PK
    user_idx        number not null,                                          -- 회원 FK
    acnt_acnt       varchar2(40) default to_char(seq_acnt_acnt.nextval) not null, -- 계좌번호
    acnt_blc        number default 0 not null,                                -- 잔액

    constraint uq_acnt_acnt unique (acnt_acnt),                               -- 계좌번호 중복 방지
    constraint ck_acnt_blc check (acnt_blc >= 0),                             -- 잔액 음수 방지
    constraint fk_acnt_user foreign key (user_idx)
        references user_info(user_idx)
)
""")


### target_info 테이블
with oracledb.connect(user=dict_01['user'], password=dict_01['password'], dsn=dict_01['url']) as conn:
    with conn.cursor() as cursor:
        cursor.execute("""
create table target_info(
    target_idx      number default seq_target_idx.nextval primary key, -- 거래대상 PK
    target_bank     varchar2(30) not null,                             -- 거래대상 은행명
    target_acnt     varchar2(30) not null,                             -- 거래대상 계좌번호
    target_blc      number default 0 not null,                         -- 거래대상 잔액
    target_name     varchar2(20) not null,                             -- 거래대상 이름

    constraint uq_target_bank_acnt unique (target_bank, target_acnt),  -- 은행+계좌번호 중복 방지
    constraint ck_target_blc check (target_blc >= 0)                   -- 잔액 음수 방지
)
""")


### detail_info 테이블
with oracledb.connect(user=dict_01['user'], password=dict_01['password'], dsn=dict_01['url']) as conn:
    with conn.cursor() as cursor:
        cursor.execute("""
create table detail_info(
    detail_idx      number default seq_detail_idx.nextval primary key, -- 거래내역 PK
    acnt_idx        number not null,                                   -- 거래 발생 계좌 FK
    target_idx      number,                                            -- 거래대상 FK (입/출금 시 null 허용)
    detail_date     timestamp default systimestamp not null,           -- 거래 일시
    detail_contnt   varchar2(100),                                    -- 거래 내용
    detail_type     varchar2(20) not null,                            -- 거래 유형
    detail_amnt     number not null,                                  -- 거래 금액
    detail_blc      number not null,                                  -- 거래 후 잔액

    constraint fk_detail_acnt foreign key (acnt_idx)
        references acnt_info(acnt_idx),

    constraint fk_detail_target foreign key (target_idx)
        references target_info(target_idx),

    constraint ck_detail_type_info check (detail_type in ('입금', '출금')),
    constraint ck_detail_amnt_info check (detail_amnt > 0),
    constraint ck_detail_blc_info check (detail_blc >= 0)
)
""")