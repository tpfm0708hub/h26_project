from func01_공통설정 import get_conn

def signup():
    user_id = input("아이디: ").strip()
    user_password = input("비밀번호: ").strip()
    user_name = input("이름: ").strip()
    user_address = input("주소: ").strip()

    try:
        #   with 구문 끝나면 알아서 종료
        with get_conn() as conn:
            with conn.cursor() as cursor:
                # 아이디 중복 확인
                # :1 첫 번째 데이터를 넣을 빈칸(예약석)
                cursor.execute("""
                    select count(*)
                    from user_info
                    where user_id = :1
                """, [user_id])# :1 자리에 user_id 값을 안전하게 입력
                # 실행 결과(행의 개수) 가져와 첫 번째 값을 cnt에 저장
                cnt = cursor.fetchone()[0]

                if cnt > 0:
                    print("이미 존재하는 아이디입니다.")
                    return
                # 순서대로 :1, :2, :3, :4 자리에 대응하는 값을 리스트 형태로 전달
                cursor.execute("""
                    insert into user_info(user_id, user_password, user_name, user_address)
                    values (:1, :2, :3, :4)
                """, [user_id, user_password, user_name, user_address])

                conn.commit()
                print("회원가입이 완료되었습니다.")

    except Exception as e:
        print("회원가입 중 오류 발생:", e)