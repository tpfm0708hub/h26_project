from func01_공통설정 import get_conn
from func05_내계좌조회 import get_my_account

def deposit(user_idx):
    # 공백 제거
    acnt_no = input("입금할 내 계좌번호: ").strip()

    try:
        amount = int(input("입금 금액: ").strip())
        if amount <= 0:
            print("입금 금액은 0보다 커야 합니다.")
            return
    except ValueError:
        print("금액은 숫자로 입력해야 합니다.")
        return

    try:
        #   with 구문 끝나면 알아서 종료
        with get_conn() as conn:
            with conn.cursor() as cursor:
                # 계좌 존재: (acnt_idx, acnt_acnt, acnt_blc)
                # 존재X: None
                my_acnt = get_my_account(cursor, user_idx, acnt_no)

                if not my_acnt:
                    print("본인 계좌가 아닙니다.")
                    return

                # _: 계좌번호 자리(사용하지 않음)
                acnt_idx, _, old_blc = my_acnt
                # 거래 후 잔액
                new_blc = old_blc + amount

                # 잔액 갱신
                cursor.execute("""
                    update acnt_info
                    set acnt_blc = :1
                    where acnt_idx = :2
                """, [new_blc, acnt_idx])
                # 거래내역 테이블에 반영
                cursor.execute("""
                    insert into detail_info(
                        acnt_idx, target_idx, detail_contnt,
                        detail_type, detail_amnt, detail_blc
                    )
                    values (:1, :2, :3, :4, :5, :6)
                """, [acnt_idx, None, '현금입금', '입금', amount, new_blc])

                conn.commit()
                print("입금이 완료되었습니다.")
                print("현재 잔액:", new_blc, "원")

    except Exception as e:
        print("입금 중 오류 발생:", e)