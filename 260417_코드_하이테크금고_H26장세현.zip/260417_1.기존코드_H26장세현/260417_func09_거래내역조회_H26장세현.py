from func01_공통설정 import get_conn
from func05_내계좌조회 import get_my_account

def show_transaction_history(user_idx):
    acnt_no = input("거래내역을 조회할 내 계좌번호: ").strip()

    try:
        #   with 구문 끝나면 알아서 종료
        with get_conn() as conn:
            with conn.cursor() as cursor:
                # 본인 계좌 여부
                my_acnt = get_my_account(cursor, user_idx, acnt_no)

                if not my_acnt:
                    print("본인 계좌가 아닙니다.")
                    return

                acnt_idx = my_acnt[0]

                # 조회항목:
                # 거래내역 idx, 일시, 내용, 유형, 금액, 잔액, 대상 은행,계좌,이름(내 스스로 입출금이면 결측)
                cursor.execute("""
                    select
                        d.detail_idx,
                        to_char(d.detail_date, 'YYYY-MM-DD HH24:MI:SS') as detail_date,
                        d.detail_contnt,
                        d.detail_type,
                        d.detail_amnt,
                        d.detail_blc,
                        nvl(t.target_bank, '-') as target_bank,
                        nvl(t.target_acnt, '-') as target_acnt,
                        nvl(t.target_name, '-') as target_name
                    from detail_info d
                    left join target_info t
                      on d.target_idx = t.target_idx
                    where d.acnt_idx = :1
                    order by d.detail_date desc, d.detail_idx desc
                """, [acnt_idx])

                rows = cursor.fetchall()

                if not rows:
                    print("거래내역이 없습니다.")
                    return

                print("\n[거래내역]")
                # 조회된 내역 1줄씩 반복 출력
                for row in rows:
                    print(
                        f"일시:{row[1]} / 내용:{row[2]} / "
                        f"유형:{row[3]} / 금액:{row[4]} / 잔액:{row[5]} / "
                        f"대상은행:{row[6]} / 대상계좌:{row[7]} / 대상명:{row[8]}"
                    )

    except Exception as e:
        print("거래내역 조회 중 오류 발생:", e)