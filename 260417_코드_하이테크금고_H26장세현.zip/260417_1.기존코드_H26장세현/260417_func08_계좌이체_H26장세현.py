from func01_공통설정 import get_conn, SYSTEM_BANK
from func05_내계좌조회 import get_my_account

# 거래대상에 있으면 기존 target_idx 반환
#            없으면 새로 갱신
def get_or_create_target(cursor, bank, target_acnt, target_name):
    cursor.execute("""
        select target_idx
        from target_info
        where target_bank = :1
          and target_acnt = :2
    """, [bank, target_acnt])

    # 조회결과 1건
    row = cursor.fetchone()
    if row:
        return row[0]

    # 내역에 존재하지 않으면 갱신
    cursor.execute("""
        insert into target_info(target_bank, target_acnt, target_name)
        values (:1, :2, :3)
    """, [bank, target_acnt, target_name])    

    cursor.execute("""
        select target_idx
        from target_info
        where target_bank = :1
          and target_acnt = :2
    """, [bank, target_acnt])
    
    # 새로 갱신된 target_idx 반환
    return cursor.fetchone()[0]

# 계좌이체 함수
# 로그인에서 받아오고
def transfer(user_idx):
    from_acnt_no = input("출금 계좌번호(내 계좌): ").strip()
    to_bank = input("입금 은행명: ").strip()
    to_acnt_no = input("입금 계좌번호: ").strip()

    try:
        amount = int(input("이체 금액: ").strip())
        if amount <= 0:
            print("이체 금액은 0보다 커야 합니다.")
            return
    except ValueError:
        print("금액은 숫자로 입력해야 합니다.")
        return

    try:
        with get_conn() as conn:
            with conn.cursor() as cursor:
                # 출금 계좌가 본인 계좌 여부 확인
                sender = get_my_account(cursor, user_idx, from_acnt_no)
                if not sender:
                    print("출금 계좌가 본인 계좌가 아닙니다.")
                    return

                sender_acnt_idx, sender_acnt_no, sender_old_blc = sender

                if sender_old_blc < amount:
                    print("잔액이 부족합니다.")
                    return

                # 내부이체이면서 같은 계좌에 보내는 거면 차단
                if to_bank == SYSTEM_BANK and from_acnt_no == to_acnt_no:
                    print("같은 계좌로 이체할 수 없습니다.")
                    return

                # 사용자 이름 조회
                cursor.execute("""
                    select user_name
                    from user_info
                    where user_idx = :1
                """, [user_idx])
                # 송금자 이름 저장
                sender_name = cursor.fetchone()[0]

                sender_new_blc = sender_old_blc - amount

                # 하이테크금고이면
                if to_bank == SYSTEM_BANK:
                    cursor.execute("""
                        select a.acnt_idx, a.acnt_acnt, a.acnt_blc, u.user_name
                        from acnt_info a
                        join user_info u
                          on a.user_idx = u.user_idx
                        where a.acnt_acnt = :1
                    """, [to_acnt_no])

                    # 조회결과 1건
                    receiver = cursor.fetchone()

                    if not receiver:
                        print("입금 계좌가 존재하지 않습니다.")
                        return

                    # 대상계좌 정보 분해: idx, 계좌번호, 잔액, 이름
                    receiver_acnt_idx, receiver_acnt_no, receiver_old_blc, receiver_name = receiver
                    receiver_new_blc = receiver_old_blc + amount

                    # 대상이 기존에 없으면 갱신, 있으면 idx 출력
                    receiver_target_idx = get_or_create_target(
                        cursor, SYSTEM_BANK, receiver_acnt_no, receiver_name
                    )
                    # 송금자도 대상 되는 거 고려
                    sender_target_idx = get_or_create_target(
                        cursor, SYSTEM_BANK, sender_acnt_no, sender_name
                    )

                    # 송금자 잔액 갱신(-)
                    cursor.execute("""
                        update acnt_info
                        set acnt_blc = :1
                        where acnt_idx = :2
                    """, [sender_new_blc, sender_acnt_idx])

                    # 대상 잔액 갱신(+)
                    cursor.execute("""
                        update acnt_info
                        set acnt_blc = :1
                        where acnt_idx = :2
                    """, [receiver_new_blc, receiver_acnt_idx])

                    # 송금자 기준 거래내역 저장
                    cursor.execute("""
                        insert into detail_info(
                            acnt_idx, target_idx, detail_contnt,
                            detail_type, detail_amnt, detail_blc
                        )
                        values (:1, :2, :3, :4, :5, :6)
                    """, [sender_acnt_idx, receiver_target_idx, '계좌이체', '출금', amount, sender_new_blc])

                    # 대상 거래내역 갱신
                    cursor.execute("""
                        insert into detail_info(
                            acnt_idx, target_idx, detail_contnt,
                            detail_type, detail_amnt, detail_blc
                        )
                        values (:1, :2, :3, :4, :5, :6)
                    """, [receiver_acnt_idx, sender_target_idx, '계좌이체', '입금', amount, receiver_new_blc])

                    conn.commit()
                    print("계좌이체가 완료되었습니다.")
                    print(f"송금 대상: {to_bank} / {to_acnt_no} / {receiver_name}")
                    print("출금 계좌 잔액:", sender_new_blc, "원")

                # 다른 은행
                else:
                    # 대상 조회
                    cursor.execute("""
                        select target_idx, target_name
                        from target_info
                        where target_bank = :1
                          and target_acnt = :2
                    """, [to_bank, to_acnt_no])

                    target_row = cursor.fetchone()

                    if not target_row:
                        print("등록되지 않은 은행/계좌번호입니다.")
                        return

                    target_idx, target_name = target_row

                    # 송금자 잔액 갱신
                    cursor.execute("""
                        update acnt_info
                        set acnt_blc = :1
                        where acnt_idx = :2
                    """, [sender_new_blc, sender_acnt_idx])

                    # 거래 내역 반영
                    cursor.execute("""
                        insert into detail_info(
                            acnt_idx, target_idx, detail_contnt,
                            detail_type, detail_amnt, detail_blc
                        )
                        values (:1, :2, :3, :4, :5, :6)
                    """, [sender_acnt_idx, target_idx, '타행출금', '출금', amount, sender_new_blc])

                    conn.commit()
                    print("계좌이체가 완료되었습니다.")
                    print(f"송금 대상: {to_bank} / {to_acnt_no} / {target_name}")
                    print("출금 계좌 잔액:", sender_new_blc, "원")

    except Exception as e:
        print("계좌이체 중 오류 발생:", e)