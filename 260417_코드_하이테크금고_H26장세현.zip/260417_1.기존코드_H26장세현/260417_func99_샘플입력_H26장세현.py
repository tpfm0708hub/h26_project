import oracledb

dict_01 = {
    'user': 'hr',
    'password': 'hr',
    'url': 'localhost:1521/free'
}

def get_conn():
    return oracledb.connect(
        user=dict_01['user'],
        password=dict_01['password'],
        dsn=dict_01['url']
    )

def insert_sample_data():
    try:
        with get_conn() as conn:
            with conn.cursor() as cursor:

                # user_info 샘플
                user_rows = [
                    {'id': 'test01', 'pw': '1111', 'name': '김민수', 'addr': '서울시 강남구'},
                    {'id': 'test02', 'pw': '2222', 'name': '이서연', 'addr': '성남시 수정구'},
                    {'id': 'test03', 'pw': '3333', 'name': '박지훈', 'addr': '수원시 영통구'}
                ]
                # sql구문
                # 새로운 id면 갱신
                for row in user_rows:
                    cursor.execute("""
                        merge into user_info u
                        using dual
                        on (u.user_id = :id)
                        when not matched then
                            insert (user_id, user_password, user_name, user_address)
                            values (:id, :pw, :name, :addr)
                    """, row)
                
                # 'test01', 'test02', 'test03'로 조회
                cursor.execute("""
                    select user_idx, user_id
                    from user_info
                    where user_id in ('test01', 'test02', 'test03')
                """)
                user_map = {user_id: user_idx for user_idx, user_id in cursor.fetchall()}
                
                # acnt_info 샘플 입력
                acnt_rows = [
                    {'idx': user_map['test01'], 'acnt': '9999999997', 'blc': 50000},
                    {'idx': user_map['test02'], 'acnt': '9999999998', 'blc': 70000},
                    {'idx': user_map['test03'], 'acnt': '9999999999', 'blc': 30000}
                ]
                
                for row in acnt_rows:
                    cursor.execute("""
                        merge into acnt_info a
                        using dual
                        on (a.acnt_acnt = :acnt)
                        when not matched then
                            insert (user_idx, acnt_acnt, acnt_blc)
                            values (:idx, :acnt, :blc)
                    """, row)
                
                # acnt_idx 조회 목록
                cursor.execute("""
                    select acnt_idx, acnt_acnt
                    from acnt_info
                    where acnt_acnt in ('9999999997', '9999999998', '9999999999')
                """)
                acnt_map = {acnt_no: acnt_idx for acnt_idx, acnt_no in cursor.fetchall()}
                
                # target_info 샘플 입력
                target_rows = [
                    {'bank': '국민은행', 'acnt': '333344445555', 'name': '홍길동', 'blc': 100000},
                    {'bank': '신한은행', 'acnt': '777788889999', 'name': '김하늘', 'blc': 120000},
                    {'bank': '하이테크금고', 'acnt': '9999999998', 'name': '이서연', 'blc': 70000},
                    {'bank': '하이테크금고', 'acnt': '9999999997', 'name': '김민수', 'blc': 50000}
                ]
                
                for row in target_rows:
                    cursor.execute("""
                        merge into target_info t
                        using dual
                        on (t.target_bank = :bank and t.target_acnt = :acnt)
                        when not matched then
                            insert (target_bank, target_acnt, target_name, target_blc)
                            values (:bank, :acnt, :name, :blc)
                        when matched then
                            update set t.target_name = :name,
                                    t.target_blc = :blc
                    """, row)
                
                # target_idx 조회용 목록(없으면 갱신)
                cursor.execute("""
                    select target_idx, target_bank, target_acnt
                    from target_info
                    where (target_bank = '국민은행' and target_acnt = '333344445555')
                       or (target_bank = '신한은행' and target_acnt = '777788889999')
                       or (target_bank = '하이테크금고' and target_acnt = '9999999998')
                       or (target_bank = '하이테크금고' and target_acnt = '9999999997')
                """)
                target_map = {(bank, acnt): idx for idx, bank, acnt in cursor.fetchall()}

                # detail_info 샘플 입력
                detail_rows = [
                    # user01 계좌 현금입금
                    (acnt_map['9999999997'], None, '현금입금', '입금', 20000, 70000),

                    # user01 계좌 현금출금
                    (acnt_map['9999999997'], None, '현금출금', '출금', 10000, 60000),

                    # user01 -> user02 이체 (송금자 기준 출금)
                    (acnt_map['9999999997'], target_map[('하이테크금고', '9999999998')], '계좌이체', '출금', 15000, 45000),

                    # user02 <- user01 이체 (수취자 기준 입금)
                    (acnt_map['9999999998'], target_map[('하이테크금고', '9999999997')], '계좌이체', '입금', 15000, 85000),

                    # user03 외부입금
                    (acnt_map['9999999999'], target_map[('국민은행', '333344445555')], '타행입금', '입금', 5000, 35000),

                    # user02 외부출금
                    (acnt_map['9999999998'], target_map[('신한은행', '777788889999')], '타행출금', '출금', 3000, 82000)
                ]

                for row in detail_rows:
                    cursor.execute("""
                        insert into detail_info(
                            acnt_idx, target_idx, detail_contnt,
                            detail_type, detail_amnt, detail_blc
                        )
                        values (:1, :2, :3, :4, :5, :6)
                    """, row)

                conn.commit()
                print("샘플 데이터 입력이 완료되었습니다.")

    except Exception as e:
        print("샘플 데이터 입력 중 오류 발생:", e)

if __name__ == "__main__":
    insert_sample_data()