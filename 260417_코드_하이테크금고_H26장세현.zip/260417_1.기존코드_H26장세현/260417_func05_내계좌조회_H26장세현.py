from func01_공통설정 import get_conn

def show_my_accounts(user_idx):
    try:
        #   with 구문 끝나면 알아서 종료
        with get_conn() as conn:
            with conn.cursor() as cursor:
                cursor.execute("""
                    select acnt_idx, acnt_acnt, acnt_blc
                    from acnt_info
                    where user_idx = :1
                    order by acnt_idx
                """, [user_idx])
                # fetchone 아니고 fetchall(해당하는 거 전부!)
                rows = cursor.fetchall()

                if not rows:
                    print("보유한 계좌가 없습니다.")
                    return

                print("\n[내 계좌 목록]")
                for row in rows:
                    print(f"계좌번호: {row[1]} / 잔액: {row[2]}원")

    except Exception as e:
        print("계좌 조회 중 오류 발생:", e)
        
# 입력한 계좌번호가 내 계좌 번호가 맞는지
def get_my_account(cursor, user_idx, acnt_no):
    cursor.execute("""
        select acnt_idx, acnt_acnt, acnt_blc
        from acnt_info
        where user_idx = :1
          and acnt_acnt = :2
    """, [user_idx, acnt_no])
    # :1 = user_idx
    # :2 = acnt_no

    return cursor.fetchone()
    # 계좌 있으면: acnt_idx, acnt_acnt, acnt_blc