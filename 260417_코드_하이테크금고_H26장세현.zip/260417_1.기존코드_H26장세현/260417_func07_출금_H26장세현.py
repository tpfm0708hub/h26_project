from func01_공통설정 import get_conn
from func05_내계좌조회 import get_my_account

def withdraw(user_idx):
    acnt_no = input("출금할 내 계좌번호: ").strip()

    try:
        amount = int(input("출금 금액: ").strip())
        if amount <= 0:
            print("출금 금액은 0보다 커야 합니다.")
            return
    except ValueError:
        print("금액은 숫자로 입력해야 합니다.")
        return

    try:
        with get_conn() as conn:
            with conn.cursor() as cursor:
                # 계좌 확인
                # TRUE면 (acnt_idx, acnt_acnt, acnt_blc)
                # FALSE면 None
                my_acnt = get_my_account(cursor, user_idx, acnt_no)

                if not my_acnt:
                    print("본인 계좌가 아닙니다.")
                    return

                # 빈자리는 할당하지 않고 무시
                acnt_idx, _, old_blc = my_acnt

                # 잔액 출금액 비교
                if old_blc < amount:
                    print("잔액이 부족합니다.")
                    return

                new_blc = old_blc - amount

                # 갱신
                cursor.execute("""
                    update acnt_info
                    set acnt_blc = :1
                    where acnt_idx = :2
                """, [new_blc, acnt_idx])

                # 거래내용에 반영
                cursor.execute("""
                    insert into detail_info(
                        acnt_idx, target_idx, detail_contnt,
                        detail_type, detail_amnt, detail_blc
                    )
                    values (:1, :2, :3, :4, :5, :6)
                """, [acnt_idx, None, '현금출금', '출금', amount, new_blc])

                conn.commit()
                print("출금이 완료되었습니다.")
                print("현재 잔액:", new_blc, "원")

    except Exception as e:
        print("출금 중 오류 발생:", e)