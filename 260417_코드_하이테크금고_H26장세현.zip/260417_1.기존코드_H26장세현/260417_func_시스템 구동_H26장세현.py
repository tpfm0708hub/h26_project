import os
path_01 = r'C:\Users\computer\Desktop\26H_장세현\과제_banksystem\제출용'

os.chdir(path = path_01)

import func11_메인메뉴

func11_메인메뉴.main()