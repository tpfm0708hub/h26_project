from func01_공통설정 import get_conn

def login():
    user_id = input("아이디: ").strip()
    user_password = input("비밀번호: ").strip()

    try:
        #   with 구문 끝나면 알아서 종료
        with get_conn() as conn:
            with conn.cursor() as cursor:
                cursor.execute("""
                    select user_idx, user_id, user_name
                    from user_info
                    where user_id = :1
                      and user_password = :2
                """, [user_id, user_password])
                #   row: 조건에 맞는 행 입력
                row = cursor.fetchone()

                if row:
                    user = {
                        "user_idx": row[0],
                        "user_id": row[1],
                        "user_name": row[2]
                    }
                    print(f"{user['user_name']}님 로그인 성공")
                    return user
                else:
                    print("아이디 또는 비밀번호가 올바르지 않습니다.")
                    return None

    except Exception as e:
        print("로그인 중 오류 발생:", e)
        return None