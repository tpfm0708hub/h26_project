from func01_공통설정 import get_conn

def create_account(user_idx):
    try:
        #   with 구문 끝나면 알아서 종료
        with get_conn() as conn:
            with conn.cursor() as cursor:
                # 새 계좌번호 생성
                cursor.execute("select to_char(seq_acnt_acnt.nextval) from dual")
                new_acnt_no = cursor.fetchone()[0]

                cursor.execute("""
                    insert into acnt_info(user_idx, acnt_acnt, acnt_blc)
                    values (:1, :2, 0)
                """, [user_idx, new_acnt_no])

                conn.commit()
                print("계좌가 생성되었습니다.")
                print("생성 계좌번호:", new_acnt_no)

    except Exception as e:
        print("계좌 생성 중 오류 발생:", e)