from func02_회원가입 import signup
from func03_로그인 import login
from func10_은행메뉴 import bank_menu

def main():
    while True:
        print("\n[메인 메뉴]")
        print("1. 회원가입")
        print("2. 로그인")
        print("3. 종료")

        menu = input("선택: ").strip()
        if menu == '1':
            signup()
        elif menu == '2':
            user = login()
            if user:
                bank_menu(user)
        elif menu == '3':
            print("프로그램을 종료합니다.")
            break
        else:
            print("올바른 메뉴 번호를 입력하세요.")


if __name__ == "__main__":
    main()