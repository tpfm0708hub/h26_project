from func01_공통설정 import get_conn, format_money


def show_my_accounts(user_idx):
    conn = None

    try:
        conn = get_conn()

        with conn.cursor() as cursor:
            # 내 계좌 조회
            cursor.execute("""
                select acnt_idx, acnt_acnt, acnt_blc
                from acnt_info
                where user_idx = :1
                order by acnt_idx
            """, [user_idx])

            rows = cursor.fetchall()

            if not rows:
                print("시스템 오류: 보유 계좌 없음")
                return

            print("\n[내 계좌 목록]")

            for i, row in enumerate(rows):
                print(f"[{i+1}] {row[1]} (잔액: {format_money(row[2])}원)")

    except Exception as e:
        print(f"시스템 오류: {e}")

    finally:
        if conn:
            conn.close()


# 본인 계좌 확인
def get_my_account(cursor, user_idx, acnt_no):
    cursor.execute("""
        select acnt_idx, acnt_acnt, acnt_blc
        from acnt_info
        where user_idx = :1
          and acnt_acnt = :2
    """, [user_idx, acnt_no])

    return cursor.fetchone()


# 내 계좌 목록 반환
def list_my_accounts(cursor, user_idx):
    cursor.execute("""
        select acnt_idx, acnt_acnt, acnt_blc
        from acnt_info
        where user_idx = :1
        order by acnt_idx
    """, [user_idx])

    return cursor.fetchall()


# 내 계좌 선택
def choose_my_account(cursor, user_idx, prompt_message="계좌 선택: "):
    rows = list_my_accounts(cursor, user_idx)

    if not rows:
        print("시스템 오류: 보유 계좌 없음")
        return None

    for i, row in enumerate(rows):
        print(f"[{i+1}] {row[1]} (잔액: {format_money(row[2])}원)")

    try:
        choice = int(input(prompt_message).strip()) - 1
    except ValueError:
        print("시스템 오류: 입력형식 오류")
        return None

    if choice < 0 or choice >= len(rows):
        print("시스템 오류: 잘못된 선택")
        return None

    return rows[choice]