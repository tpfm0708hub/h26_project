from func01_공통설정 import (
    get_conn,
    rollback_conn,
    SYSTEM_BANK,
    BANK_MENU,
    parse_money,
    format_money,
    get_masked_input,
    verify_current_password,
    print_transfer_summary,
    ask_confirm,
    print_bank_menu,
    get_user_name,
    get_or_create_target,
    sync_internal_target
)
from func05_내계좌조회 import choose_my_account


def transfer(user_idx):
    print("\n[계좌이체]")
    print("1. 내계좌전송")
    print("2. 계좌이체")

    transfer_mode = input("선택: ").strip()

    if transfer_mode not in ('1', '2'):
        print("시스템 오류: 잘못된 선택")
        return

    conn = None

    try:
        conn = get_conn()

        with conn.cursor() as cursor:
            # 출금 계좌 선택
            sender = choose_my_account(cursor, user_idx, "계좌 선택: ")

            if not sender:
                return

            sender_acnt_idx, sender_acnt_no, sender_old_blc = sender
            sender_name = get_user_name(cursor, user_idx)

            receiver_acnt_idx = None
            receiver_acnt_no = None
            receiver_old_blc = None
            receiver_name = None

            external_target_idx = None
            external_target_name = None
            external_target_old_blc = None

            to_bank = None
            detail_contnt = None
            is_internal = False

            # 내계좌전송
            if transfer_mode == '1':
                is_internal = True
                detail_contnt = '내계좌전송'
                to_bank = SYSTEM_BANK

                receiver = choose_my_account(cursor, user_idx, "계좌 선택: ")

                if not receiver:
                    return

                receiver_acnt_idx, receiver_acnt_no, receiver_old_blc = receiver
                receiver_name = sender_name

                if sender_acnt_no == receiver_acnt_no:
                    print("시스템 오류: 동일 계좌 이체 불가")
                    return

            # 계좌이체
            else:
                print_bank_menu()

                bank_choice = input("선택: ").strip()

                if bank_choice not in BANK_MENU:
                    print("시스템 오류: 잘못된 선택")
                    return

                to_bank = BANK_MENU[bank_choice]

                # 내부은행 이체
                if to_bank == SYSTEM_BANK:
                    is_internal = True
                    detail_contnt = '계좌이체'

                    receiver_acnt_no = input("계좌번호: ").strip()

                    if sender_acnt_no == receiver_acnt_no:
                        print("시스템 오류: 동일 계좌 이체 불가")
                        return

                    cursor.execute("""
                        select a.acnt_idx, a.acnt_acnt, a.acnt_blc, u.user_name
                        from acnt_info a
                        join user_info u
                          on a.user_idx = u.user_idx
                        where a.acnt_acnt = :1
                    """, [receiver_acnt_no])

                    receiver = cursor.fetchone()

                    if not receiver:
                        print("시스템 오류: 계좌 정보 불일치")
                        return

                    receiver_acnt_idx = receiver[0]
                    receiver_acnt_no = receiver[1]
                    receiver_old_blc = receiver[2]
                    receiver_name = receiver[3]

                # 타행 이체
                else:
                    is_internal = False
                    detail_contnt = '타행출금'
                    receiver_acnt_no = input("계좌번호: ").strip()

                    cursor.execute("""
                        select target_idx, target_name, target_blc
                        from target_info
                        where target_bank = :1
                          and target_acnt = :2
                    """, [to_bank, receiver_acnt_no])

                    ext_row = cursor.fetchone()

                    if not ext_row:
                        print("시스템 오류: 계좌 정보 불일치")
                        return

                    external_target_idx = ext_row[0]
                    external_target_name = ext_row[1]
                    external_target_old_blc = ext_row[2]

            amount = parse_money(input("금액: "))

            if amount <= 0:
                print("시스템 오류: 0원 입력 불가")
                return

            if amount > sender_old_blc:
                print("시스템 오류: 잔액 부족")
                return

            # 비밀번호 확인
            input_pw = get_masked_input("비밀번호: ")

            if not verify_current_password(cursor, user_idx, input_pw):
                print("시스템 오류: 비밀번호 불일치")
                return

            # 요약 출력
            if is_internal:
                summary_name = receiver_name
                summary_acnt = receiver_acnt_no
            else:
                summary_name = external_target_name
                summary_acnt = receiver_acnt_no

            print_transfer_summary(
                title="계좌이체",
                from_acnt=sender_acnt_no,
                amount=amount,
                to_bank=to_bank,
                to_acnt=summary_acnt,
                to_name=summary_name
            )

            if not ask_confirm("이체하시겠습니까?"):
                print("계좌이체 취소")
                return

            sender_new_blc = sender_old_blc - amount

            # 출금 계좌 갱신
            cursor.execute("""
                update acnt_info
                set acnt_blc = :1
                where acnt_idx = :2
            """, [sender_new_blc, sender_acnt_idx])

            sync_internal_target(
                cursor,
                sender_acnt_no,
                sender_name,
                sender_new_blc
            )

            # 내부 이체
            if is_internal:
                receiver_new_blc = receiver_old_blc + amount

                # 입금 계좌 갱신
                cursor.execute("""
                    update acnt_info
                    set acnt_blc = :1
                    where acnt_idx = :2
                """, [receiver_new_blc, receiver_acnt_idx])

                receiver_target_idx = sync_internal_target(
                    cursor,
                    receiver_acnt_no,
                    receiver_name,
                    receiver_new_blc
                )

                sender_target_idx = sync_internal_target(
                    cursor,
                    sender_acnt_no,
                    sender_name,
                    sender_new_blc
                )

                # 출금 거래내역
                cursor.execute("""
                    insert into detail_info(
                        acnt_idx, target_idx, detail_contnt,
                        detail_type, detail_amnt, detail_blc
                    )
                    values (:1, :2, :3, :4, :5, :6)
                """, [
                    sender_acnt_idx,
                    receiver_target_idx,
                    detail_contnt,
                    '출금',
                    amount,
                    sender_new_blc
                ])

                # 입금 거래내역
                cursor.execute("""
                    insert into detail_info(
                        acnt_idx, target_idx, detail_contnt,
                        detail_type, detail_amnt, detail_blc
                    )
                    values (:1, :2, :3, :4, :5, :6)
                """, [
                    receiver_acnt_idx,
                    sender_target_idx,
                    detail_contnt,
                    '입금',
                    amount,
                    receiver_new_blc
                ])

            # 외부 이체
            else:
                external_target_new_blc = external_target_old_blc + amount

                # 외부 계좌 잔액 증가
                cursor.execute("""
                    update target_info
                    set target_blc = :1
                    where target_idx = :2
                """, [external_target_new_blc, external_target_idx])

                get_or_create_target(
                    cursor,
                    to_bank,
                    receiver_acnt_no,
                    external_target_name,
                    external_target_new_blc
                )

                # 출금 거래내역
                cursor.execute("""
                    insert into detail_info(
                        acnt_idx, target_idx, detail_contnt,
                        detail_type, detail_amnt, detail_blc
                    )
                    values (:1, :2, :3, :4, :5, :6)
                """, [
                    sender_acnt_idx,
                    external_target_idx,
                    detail_contnt,
                    '출금',
                    amount,
                    sender_new_blc
                ])

        conn.commit()
        print(f"계좌이체 완료: 잔액 {format_money(sender_new_blc)}원")

    except Exception as e:
        rollback_conn(conn)
        print(f"시스템 오류: {e}")

    finally:
        if conn:
            conn.close()