from func01_공통설정 import (
    get_conn,
    rollback_conn,
    parse_money,
    format_money,
    get_user_name,
    sync_internal_target
)
from func05_내계좌조회 import get_my_account


def deposit(user_idx):
    acnt_no = input("계좌번호: ").strip()
    amount = parse_money(input("금액: ").strip())

    if amount <= 0:
        print("시스템 오류: 0원 입력 불가")
        return

    conn = None

    try:
        conn = get_conn()

        with conn.cursor() as cursor:
            # 계좌 확인
            my_acnt = get_my_account(cursor, user_idx, acnt_no)

            if not my_acnt:
                print("시스템 오류: 계좌 정보 불일치")
                return

            acnt_idx, _, old_blc = my_acnt
            new_blc = old_blc + amount

            # 잔액 갱신
            cursor.execute("""
                update acnt_info
                set acnt_blc = :1
                where acnt_idx = :2
            """, [new_blc, acnt_idx])

            # target 동기화
            user_name = get_user_name(cursor, user_idx)

            sync_internal_target(
                cursor,
                acnt_no,
                user_name,
                new_blc
            )

            # 거래내역 기록
            cursor.execute("""
                insert into detail_info(
                    acnt_idx, target_idx, detail_contnt,
                    detail_type, detail_amnt, detail_blc
                )
                values (:1, :2, :3, :4, :5, :6)
            """, [acnt_idx, None, '현금입금', '입금', amount, new_blc])

        conn.commit()
        print(f"입금 완료: 잔액 {format_money(new_blc)}원")

    except Exception as e:
        rollback_conn(conn)
        print(f"시스템 오류: {e}")

    finally:
        if conn:
            conn.close()