import oracledb
import re
import sys
from getpass import getpass

try:
    import msvcrt
    HAS_MSVCRT = True
except ImportError:
    HAS_MSVCRT = False


dict_01 = {
    'user': 'hr',
    'password': 'hr',
    'url': 'localhost:1521/free'
}

SYSTEM_BANK = "하이테크금고"

BANK_MENU = {
    '0': SYSTEM_BANK,
    '1': '신한은행',
    '2': 'KB국민은행',
    '3': '하나은행',
    '4': '우리은행'
}


def get_conn():
    return oracledb.connect(
        user=dict_01['user'],
        password=dict_01['password'],
        dsn=dict_01['url']
    )


# rollback 처리
def rollback_conn(conn):
    try:
        if conn:
            conn.rollback()
    except Exception:
        pass


# 금액 입력 형식 상관 없이
def parse_money(amount_str):
    try:
        cleaned = str(amount_str).replace(',', '').strip()
        return int(cleaned)
    except Exception:
        return -1


# 금액 comma()
def format_money(amount):
    return f"{int(amount):,}"


# 회원가입 ID 입력 양식
def validate_signup_id(user_id):
    pattern = r'^(?=.*[a-z])(?=.*\d)[a-z\d]{5,}$'
    return bool(re.fullmatch(pattern, user_id))


# 회원가입 비밀번호 입력 양식
def validate_signup_password(user_password):
    pattern = r'^\d{6}$'
    return bool(re.fullmatch(pattern, user_password))


# getpass 숨김 입력
def get_hidden_input(prompt="비밀번호: "):
    return getpass(prompt)


# windows * 마스킹 입력
def get_masked_input(prompt="비밀번호: "):
    if not HAS_MSVCRT:
        return get_hidden_input(prompt)

    print(prompt, end='', flush=True)
    password = ""

    while True:
        ch = msvcrt.getch()

        if ch in (b'\r', b'\n'):
            print()
            break

        if ch == b'\x08':
            if password:
                password = password[:-1]
                sys.stdout.write('\b \b')
                sys.stdout.flush()
            continue

        if ch in (b'\x00', b'\xe0'):
            try:
                msvcrt.getch()
            except Exception:
                pass
            continue

        try:
            decoded = ch.decode('utf-8')
        except UnicodeDecodeError:
            decoded = ''

        if decoded:
            password += decoded
            sys.stdout.write('*')
            sys.stdout.flush()

    return password


# y/n 팝업창
def ask_confirm(message):
    while True:
        choice = input(f"{message} (Y/N): ").strip().upper()

        if choice == 'Y':
            return True

        if choice == 'N':
            return False

        print("Y 또는 N만 입력해 주세요.")


# 현재 로그인 사용자 비밀번호 검증
def verify_current_password(cursor, user_idx, input_password):
    cursor.execute("""
        select user_password
        from user_info
        where user_idx = :1
    """, [user_idx])

    row = cursor.fetchone()

    if not row:
        return False

    return row[0] == input_password


# 사용자 이름 조회
def get_user_name(cursor, user_idx):
    cursor.execute("""
        select user_name
        from user_info
        where user_idx = :1
    """, [user_idx])

    row = cursor.fetchone()

    if row:
        return row[0]

    return None


# 거래대상 조회 후 없으면 생성
def get_or_create_target(cursor, bank, target_acnt, target_name, target_blc=0):
    cursor.execute("""
        select target_idx
        from target_info
        where target_bank = :1
          and target_acnt = :2
    """, [bank, target_acnt])

    row = cursor.fetchone()

    if row:
        target_idx = row[0]

        cursor.execute("""
            update target_info
            set target_name = :1,
                target_blc = :2
            where target_idx = :3
        """, [target_name, target_blc, target_idx])

        return target_idx

    cursor.execute("""
        insert into target_info(
            target_bank, target_acnt, target_name, target_blc
        )
        values (:1, :2, :3, :4)
    """, [bank, target_acnt, target_name, target_blc])

    cursor.execute("""
        select target_idx
        from target_info
        where target_bank = :1
          and target_acnt = :2
    """, [bank, target_acnt])

    return cursor.fetchone()[0]


# 내부 계좌를 target_info에 동기화
def sync_internal_target(cursor, acnt_no, user_name, balance):
    return get_or_create_target(
        cursor,
        SYSTEM_BANK,
        acnt_no,
        user_name,
        balance
    )


# 거래 요약 출력
def print_transfer_summary(title, from_acnt, amount, to_bank='-', to_acnt='-', to_name='-'):
    print("\n" + "=" * 60)
    print(f"[{title} 거래 요약]")
    print(f"출금계좌 : {from_acnt}")
    print(f"입금은행 : {to_bank}")
    print(f"입금계좌 : {to_acnt}")
    print(f"예금주명 : {to_name}")
    print(f"거래금액 : {format_money(amount)}원")
    print("=" * 60)


# 은행 메뉴 출력
def print_bank_menu():
    print("\n[은행 선택]")

    for key, bank_name in BANK_MENU.items():
        print(f"{key}. {bank_name}")