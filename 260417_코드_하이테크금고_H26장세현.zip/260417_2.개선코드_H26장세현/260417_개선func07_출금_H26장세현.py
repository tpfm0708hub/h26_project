from func01_공통설정 import (
    get_conn,
    rollback_conn,
    parse_money,
    format_money,
    get_masked_input,
    verify_current_password,
    print_transfer_summary,
    ask_confirm,
    get_user_name,
    sync_internal_target
)
from func05_내계좌조회 import get_my_account


def withdraw(user_idx):
    acnt_no = input("계좌번호: ").strip()
    amount = parse_money(input("금액: "))

    if amount <= 0:
        print("시스템 오류: 0원 입력 불가")
        return

    conn = None

    try:
        conn = get_conn()

        with conn.cursor() as cursor:
            # 계좌 확인
            my_acnt = get_my_account(cursor, user_idx, acnt_no)

            if not my_acnt:
                print("시스템 오류: 계좌 정보 불일치")
                return

            acnt_idx, _, old_blc = my_acnt

            # 잔액 확인
            if old_blc < amount:
                print("시스템 오류: 잔액 부족")
                return

            # 비밀번호 확인
            input_pw = get_masked_input("비밀번호: ")

            if not verify_current_password(cursor, user_idx, input_pw):
                print("시스템 오류: 비밀번호 불일치")
                return

            # 거래 요약 출력
            print_transfer_summary(
                title="출금",
                from_acnt=acnt_no,
                amount=amount,
                to_bank="현금출금",
                to_acnt="-",
                to_name="-"
            )

            if not ask_confirm("출금하시겠습니까?"):
                print("출금 취소")
                return

            new_blc = old_blc - amount

            # 잔액 갱신
            cursor.execute("""
                update acnt_info
                set acnt_blc = :1
                where acnt_idx = :2
            """, [new_blc, acnt_idx])

            # target 동기화
            user_name = get_user_name(cursor, user_idx)

            sync_internal_target(
                cursor,
                acnt_no,
                user_name,
                new_blc
            )

            # 거래내역 기록
            cursor.execute("""
                insert into detail_info(
                    acnt_idx, target_idx, detail_contnt,
                    detail_type, detail_amnt, detail_blc
                )
                values (:1, :2, :3, :4, :5, :6)
            """, [acnt_idx, None, '현금출금', '출금', amount, new_blc])

        conn.commit()
        print(f"출금 완료: 잔액 {format_money(new_blc)}원")

    except Exception as e:
        rollback_conn(conn)
        print(f"시스템 오류: {e}")

    finally:
        if conn:
            conn.close()