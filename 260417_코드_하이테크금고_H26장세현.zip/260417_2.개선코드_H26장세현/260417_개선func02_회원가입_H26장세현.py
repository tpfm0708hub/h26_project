from func01_공통설정 import (
    get_conn,
    rollback_conn,
    validate_signup_id,
    validate_signup_password
)


def signup():
    print("\n[회원가입]")

    while True:
        print("\n아이디: 영문 소문자 및 숫자 조합(5자 이상)")
        user_id = input("아이디: ").strip()

        if not validate_signup_id(user_id):
            print("시스템 오류: 입력형식 오류")
            continue

        conn = None

        try:
            conn = get_conn()

            with conn.cursor() as cursor:
                # id 중복 확인
                cursor.execute("""
                    select count(*)
                    from user_info
                    where user_id = :1
                """, [user_id])

                cnt = cursor.fetchone()[0]

                if cnt > 0:
                    print("시스템 오류: 중복 ID")
                    continue

            break

        except Exception as e:
            print(f"시스템 오류: {e}")

        finally:
            if conn:
                conn.close()

    while True:
        print("\n비밀번호: 숫자 6자리")
        user_password = input("비밀번호: ").strip()

        if not validate_signup_password(user_password):
            print("시스템 오류: 입력형식 오류")
            continue

        user_password_check = input("비밀번호 확인: ").strip()

        if user_password != user_password_check:
            print("시스템 오류: 비밀번호 불일치")
            continue

        break

    while True:
        user_name = input("이름: ").strip()

        if not user_name:
            print("시스템 오류: 필수 입력값 누락")
            continue

        break

    while True:
        user_address = input("주소: ").strip()

        if not user_address:
            print("시스템 오류: 필수 입력값 누락")
            continue

        break

    conn = None

    try:
        conn = get_conn()

        with conn.cursor() as cursor:
            # 회원정보 입력
            cursor.execute("""
                insert into user_info(
                    user_id, user_password, user_name, user_address
                )
                values (:1, :2, :3, :4)
            """, [user_id, user_password, user_name, user_address])

        conn.commit()
        print("회원가입 완료")

    except Exception as e:
        rollback_conn(conn)
        print(f"시스템 오류: {e}")

    finally:
        if conn:
            conn.close()