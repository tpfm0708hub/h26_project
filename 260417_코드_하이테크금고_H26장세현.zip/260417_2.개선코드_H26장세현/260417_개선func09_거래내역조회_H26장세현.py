from func01_공통설정 import get_conn, format_money
from func05_내계좌조회 import choose_my_account


def show_transaction_history(user_idx):
    print("\n[거래내역 조회]")

    conn = None

    try:
        conn = get_conn()

        with conn.cursor() as cursor:
            # 계좌 선택
            selected_account = choose_my_account(cursor, user_idx, "선택(번호): ")

            if not selected_account:
                return

            acnt_idx, acnt_no, _ = selected_account

            # 거래내역 조회
            cursor.execute("""
                select
                    to_char(d.detail_date, 'YYYY-MM-DD HH24:MI:SS'),
                    d.detail_contnt,
                    d.detail_type,
                    d.detail_amnt,
                    d.detail_blc,
                    nvl(t.target_bank, '-'),
                    nvl(t.target_acnt, '-'),
                    nvl(t.target_name, '-')
                from detail_info d
                left join target_info t
                  on d.target_idx = t.target_idx
                where d.acnt_idx = :1
                order by d.detail_date desc, d.detail_idx desc
            """, [acnt_idx])

            rows = cursor.fetchall()

            if not rows:
                print(f"\n[거래 내역 - {acnt_no}]")
                print("시스템 오류: 내역 없음")
                return

            print(f"\n[거래 내역 - {acnt_no}]")
            print("-" * 110)

            for row in rows:
                bank_display = row[5] if row[5] != '-' else "-"
                print(
                    f"[{row[0]}] {row[1]}({row[2]}) | "
                    f"금액:{format_money(row[3]):>10} | "
                    f"잔액:{format_money(row[4]):>10} | "
                    f"상대:{bank_display} / {row[6]} / {row[7]}"
                )

            print("-" * 110)

    except Exception as e:
        print(f"시스템 오류: {e}")

    finally:
        if conn:
            conn.close()