from func01_공통설정 import get_conn, get_masked_input


def login():
    print("\n[로그인]")

    user_id = input("아이디: ").strip()
    user_password = get_masked_input("비밀번호: ")

    conn = None

    try:
        conn = get_conn()

        with conn.cursor() as cursor:
            # 사용자 조회
            cursor.execute("""
                select user_idx, user_id, user_name
                from user_info
                where user_id = :1
                  and user_password = :2
            """, [user_id, user_password])

            row = cursor.fetchone()

            if row:
                print(f"\n{row[2]}님 환영합니다!")
                return {
                    "user_idx": row[0],
                    "user_id": row[1],
                    "user_name": row[2]
                }

            print("\n시스템 오류: 입력정보 불일치")
            return None

    except Exception as e:
        print(f"시스템 오류: {e}")
        return None

    finally:
        if conn:
            conn.close()