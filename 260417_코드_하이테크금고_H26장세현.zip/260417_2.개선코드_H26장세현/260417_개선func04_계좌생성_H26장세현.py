from func01_공통설정 import (
    get_conn,
    rollback_conn,
    get_user_name,
    sync_internal_target
)


def create_account(user_idx):
    conn = None

    try:
        conn = get_conn()

        with conn.cursor() as cursor:
            # 계좌번호 생성
            cursor.execute("select to_char(seq_acnt_acnt.nextval) from dual")
            new_acnt_no = cursor.fetchone()[0]

            # 계좌 생성
            cursor.execute("""
                insert into acnt_info(user_idx, acnt_acnt, acnt_blc)
                values (:1, :2, 0)
            """, [user_idx, new_acnt_no])

            # target 동기화
            user_name = get_user_name(cursor, user_idx)

            sync_internal_target(
                cursor,
                new_acnt_no,
                user_name,
                0
            )

        conn.commit()
        print(f"계좌 생성 완료: {new_acnt_no}")

    except Exception as e:
        rollback_conn(conn)
        print(f"시스템 오류: {e}")

    finally:
        if conn:
            conn.close()