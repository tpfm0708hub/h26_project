from func04_계좌생성 import create_account
from func05_내계좌조회 import show_my_accounts
from func06_입금 import deposit
from func07_출금 import withdraw
from func08_계좌이체 import transfer
from func09_거래내역조회 import show_transaction_history


def bank_menu(user):
    while True:
        print(f"\n--- {user['user_name']}님 업무 선택 ---")
        print("1. 내 계좌 생성")
        print("2. 내 계좌 조회")
        print("3. 입금")
        print("4. 출금")
        print("5. 계좌이체")
        print("6. 거래내역 조회")
        print("7. 로그아웃")

        menu = input("선택: ").strip()

        if menu == '1':
            create_account(user['user_idx'])

        elif menu == '2':
            show_my_accounts(user['user_idx'])

        elif menu == '3':
            deposit(user['user_idx'])

        elif menu == '4':
            withdraw(user['user_idx'])

        elif menu == '5':
            transfer(user['user_idx'])

        elif menu == '6':
            show_transaction_history(user['user_idx'])

        elif menu == '7':
            break

        else:
            print("시스템 오류: 잘못된 선택")